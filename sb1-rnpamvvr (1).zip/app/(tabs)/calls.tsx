import React, { useState } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  Image,
} from 'react-native';
import { Phone, Video, PhoneCall, VideoIcon, PhoneIncoming, PhoneOutgoing, PhoneMissed } from 'lucide-react-native';

interface Call {
  id: string;
  name: string;
  avatar: string;
  timestamp: string;
  type: 'incoming' | 'outgoing' | 'missed';
  callType: 'audio' | 'video';
  duration?: string;
}

const mockCalls: Call[] = [
  {
    id: '1',
    name: 'Sarah Johnson',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    timestamp: 'Hari ini, 10:30',
    type: 'incoming',
    callType: 'video',
    duration: '12:45',
  },
  {
    id: '2',
    name: 'David Chen',
    avatar: 'https://images.pexels.com/photos/1300402/pexels-photo-1300402.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    timestamp: 'Hari ini, 09:15',
    type: 'outgoing',
    callType: 'audio',
    duration: '5:23',
  },
  {
    id: '3',
    name: 'Lisa Wang',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    timestamp: 'Kemarin, 18:22',
    type: 'missed',
    callType: 'audio',
  },
  {
    id: '4',
    name: 'Tim Marketing',
    avatar: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    timestamp: 'Kemarin, 14:10',
    type: 'incoming',
    callType: 'video',
    duration: '1:45:12',
  },
  {
    id: '5',
    name: 'John Doe',
    avatar: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    timestamp: '2 hari yang lalu',
    type: 'outgoing',
    callType: 'audio',
    duration: '0:45',
  },
];

export default function CallsScreen() {
  const [calls] = useState<Call[]>(mockCalls);

  const getCallIcon = (type: string, callType: string) => {
    const size = 16;
    const color = type === 'missed' ? '#FF3333' : '#34C759';
    
    switch (type) {
      case 'incoming':
        return <PhoneIncoming size={size} color={color} />;
      case 'outgoing':
        return <PhoneOutgoing size={size} color={color} />;
      case 'missed':
        return <PhoneMissed size={size} color={color} />;
      default:
        return <Phone size={size} color={color} />;
    }
  };

  const renderCallItem = ({ item }: { item: Call }) => (
    <TouchableOpacity style={styles.callItem}>
      <Image source={{ uri: item.avatar }} style={styles.avatar} />
      
      <View style={styles.callContent}>
        <View style={styles.callHeader}>
          <Text style={styles.callName}>{item.name}</Text>
          <TouchableOpacity style={styles.callButton}>
            {item.callType === 'video' ? (
              <Video size={20} color="#007AFF" />
            ) : (
              <Phone size={20} color="#007AFF" />
            )}
          </TouchableOpacity>
        </View>
        
        <View style={styles.callInfo}>
          <View style={styles.callDetails}>
            {getCallIcon(item.type, item.callType)}
            <Text style={[
              styles.callTimestamp,
              item.type === 'missed' && styles.missedCall
            ]}>
              {item.timestamp}
            </Text>
          </View>
          {item.duration && (
            <Text style={styles.callDuration}>{item.duration}</Text>
          )}
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Panggilan</Text>
        <View style={styles.headerActions}>
          <TouchableOpacity style={styles.headerButton}>
            <Phone size={24} color="#007AFF" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.headerButton}>
            <Video size={24} color="#007AFF" />
          </TouchableOpacity>
        </View>
      </View>

      <FlatList
        data={calls}
        keyExtractor={(item) => item.id}
        renderItem={renderCallItem}
        style={styles.callList}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <PhoneCall size={64} color="#C7C7CC" />
            <Text style={styles.emptyTitle}>Belum ada panggilan</Text>
            <Text style={styles.emptySubtitle}>
              Riwayat panggilan Anda akan muncul di sini
            </Text>
          </View>
        }
      />

      <View style={styles.fabContainer}>
        <TouchableOpacity style={[styles.fab, styles.fabSecondary]}>
          <Video size={24} color="#FFFFFF" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.fab}>
          <Phone size={24} color="#FFFFFF" />
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 8,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#F2F2F7',
  },
  title: {
    fontSize: 32,
    fontFamily: 'Inter-Bold',
    color: '#1C1C1E',
  },
  headerActions: {
    flexDirection: 'row',
    gap: 8,
  },
  headerButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F2F2F7',
    alignItems: 'center',
    justifyContent: 'center',
  },
  callList: {
    flex: 1,
  },
  callItem: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 12,
    alignItems: 'center',
  },
  avatar: {
    width: 52,
    height: 52,
    borderRadius: 26,
    marginRight: 12,
  },
  callContent: {
    flex: 1,
  },
  callHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  callName: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1C1C1E',
  },
  callButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#F2F2F7',
    alignItems: 'center',
    justifyContent: 'center',
  },
  callInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  callDetails: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  callTimestamp: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#8E8E93',
  },
  missedCall: {
    color: '#FF3333',
  },
  callDuration: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#8E8E93',
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 64,
    paddingHorizontal: 32,
  },
  emptyTitle: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: '#1C1C1E',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#8E8E93',
    textAlign: 'center',
  },
  fabContainer: {
    position: 'absolute',
    bottom: 24,
    right: 24,
    flexDirection: 'column',
    gap: 12,
  },
  fab: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#007AFF',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  fabSecondary: {
    backgroundColor: '#34C759',
  },
});