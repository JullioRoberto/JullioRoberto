import React, { useState } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  Image,
  ScrollView,
} from 'react-native';
import { Plus, Camera, Settings } from 'lucide-react-native';

interface Status {
  id: string;
  name: string;
  avatar: string;
  timestamp: string;
  viewed: boolean;
  isMyStatus?: boolean;
}

const mockStatuses: Status[] = [
  {
    id: '1',
    name: 'Status Saya',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    timestamp: 'Tap untuk menambah status',
    viewed: false,
    isMyStatus: true,
  },
  {
    id: '2',
    name: 'Sarah Johnson',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    timestamp: '5 menit yang lalu',
    viewed: false,
  },
  {
    id: '3',
    name: 'David Chen',
    avatar: 'https://images.pexels.com/photos/1300402/pexels-photo-1300402.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    timestamp: '1 jam yang lalu',
    viewed: true,
  },
  {
    id: '4',
    name: 'Lisa Wang',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    timestamp: '3 jam yang lalu',
    viewed: false,
  },
  {
    id: '5',
    name: 'Team Project',
    avatar: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    timestamp: '6 jam yang lalu',
    viewed: true,
  },
];

export default function StatusScreen() {
  const [statuses] = useState<Status[]>(mockStatuses);
  
  const myStatus = statuses.find(status => status.isMyStatus);
  const otherStatuses = statuses.filter(status => !status.isMyStatus);
  const recentStatuses = otherStatuses.filter(status => !status.viewed);
  const viewedStatuses = otherStatuses.filter(status => status.viewed);

  const renderStatusItem = ({ item }: { item: Status }) => (
    <TouchableOpacity style={styles.statusItem}>
      <View style={styles.avatarContainer}>
        <Image source={{ uri: item.avatar }} style={styles.avatar} />
        {!item.viewed && !item.isMyStatus && <View style={styles.unviewedRing} />}
        {item.isMyStatus && (
          <View style={styles.addStatusButton}>
            <Plus size={16} color="#FFFFFF" />
          </View>
        )}
      </View>
      
      <View style={styles.statusContent}>
        <Text style={styles.statusName}>{item.name}</Text>
        <Text style={[
          styles.statusTimestamp,
          item.isMyStatus && styles.statusPlaceholder
        ]}>
          {item.timestamp}
        </Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Status</Text>
        <View style={styles.headerActions}>
          <TouchableOpacity style={styles.headerButton}>
            <Camera size={24} color="#007AFF" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.headerButton}>
            <Settings size={24} color="#007AFF" />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* My Status */}
        {myStatus && (
          <View style={styles.section}>
            <TouchableOpacity style={styles.statusItem}>
              <View style={styles.avatarContainer}>
                <Image source={{ uri: myStatus.avatar }} style={styles.avatar} />
                <View style={styles.addStatusButton}>
                  <Plus size={16} color="#FFFFFF" />
                </View>
              </View>
              
              <View style={styles.statusContent}>
                <Text style={styles.statusName}>{myStatus.name}</Text>
                <Text style={styles.statusPlaceholder}>{myStatus.timestamp}</Text>
              </View>
            </TouchableOpacity>
          </View>
        )}

        {/* Recent Updates */}
        {recentStatuses.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Pembaruan terbaru</Text>
            <FlatList
              data={recentStatuses}
              keyExtractor={(item) => item.id}
              renderItem={renderStatusItem}
              scrollEnabled={false}
            />
          </View>
        )}

        {/* Viewed Updates */}
        {viewedStatuses.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Telah dilihat</Text>
            <FlatList
              data={viewedStatuses}
              keyExtractor={(item) => item.id}
              renderItem={renderStatusItem}
              scrollEnabled={false}
            />
          </View>
        )}
      </ScrollView>

      <TouchableOpacity style={styles.fab}>
        <Camera size={24} color="#FFFFFF" />
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 8,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#F2F2F7',
  },
  title: {
    fontSize: 32,
    fontFamily: 'Inter-Bold',
    color: '#1C1C1E',
  },
  headerActions: {
    flexDirection: 'row',
    gap: 8,
  },
  headerButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F2F2F7',
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    flex: 1,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#8E8E93',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    paddingHorizontal: 16,
    marginBottom: 8,
  },
  statusItem: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 12,
    alignItems: 'center',
  },
  avatarContainer: {
    position: 'relative',
    marginRight: 12,
  },
  avatar: {
    width: 52,
    height: 52,
    borderRadius: 26,
  },
  unviewedRing: {
    position: 'absolute',
    top: -2,
    left: -2,
    width: 56,
    height: 56,
    borderRadius: 28,
    borderWidth: 3,
    borderColor: '#007AFF',
  },
  addStatusButton: {
    position: 'absolute',
    bottom: -2,
    right: -2,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: '#34C759',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  statusContent: {
    flex: 1,
  },
  statusName: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1C1C1E',
    marginBottom: 2,
  },
  statusTimestamp: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#8E8E93',
  },
  statusPlaceholder: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#C7C7CC',
  },
  fab: {
    position: 'absolute',
    bottom: 24,
    right: 24,
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#007AFF',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
});