import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  Image,
  ScrollView,
  Switch,
} from 'react-native';
import { 
  Settings, 
  Edit, 
  Bell, 
  Shield, 
  HelpCircle, 
  Heart, 
  LogOut,
  ChevronRight,
  Moon,
  Globe,
  Database,
  Camera
} from 'lucide-react-native';

interface ProfileOption {
  id: string;
  title: string;
  subtitle?: string;
  icon: React.ReactNode;
  type: 'navigation' | 'toggle' | 'action';
  value?: boolean;
  onPress?: () => void;
  onToggle?: (value: boolean) => void;
}

export default function ProfileScreen() {
  const [darkMode, setDarkMode] = useState(false);
  const [notifications, setNotifications] = useState(true);

  const profileOptions: ProfileOption[] = [
    {
      id: 'account',
      title: 'Akun',
      subtitle: 'Privasi, keamanan, ubah nomor',
      icon: <Shield size={24} color="#007AFF" />,
      type: 'navigation',
      onPress: () => console.log('Account settings'),
    },
    {
      id: 'notifications',
      title: 'Notifikasi',
      subtitle: 'Pesan, grup, panggilan',
      icon: <Bell size={24} color="#FF9500" />,
      type: 'toggle',
      value: notifications,
      onToggle: setNotifications,
    },
    {
      id: 'appearance',
      title: 'Mode Gelap',
      subtitle: 'Tema gelap',
      icon: <Moon size={24} color="#8E8E93" />,
      type: 'toggle',
      value: darkMode,
      onToggle: setDarkMode,
    },
    {
      id: 'language',
      title: 'Bahasa',
      subtitle: 'Indonesia',
      icon: <Globe size={24} color="#34C759" />,
      type: 'navigation',
      onPress: () => console.log('Language settings'),
    },
    {
      id: 'storage',
      title: 'Penyimpanan dan Data',
      subtitle: 'Penggunaan jaringan',
      icon: <Database size={24} color="#8E8E93" />,
      type: 'navigation',
      onPress: () => console.log('Storage settings'),
    },
    {
      id: 'help',
      title: 'Bantuan',
      subtitle: 'FAQ, hubungi kami',
      icon: <HelpCircle size={24} color="#007AFF" />,
      type: 'navigation',
      onPress: () => console.log('Help'),
    },
    {
      id: 'about',
      title: 'Tentang LIORA',
      subtitle: 'Versi 1.0.0',
      icon: <Heart size={24} color="#FF3333" />,
      type: 'navigation',
      onPress: () => console.log('About'),
    },
  ];

  const renderProfileOption = (option: ProfileOption) => (
    <TouchableOpacity
      key={option.id}
      style={styles.optionItem}
      onPress={option.onPress}
      disabled={option.type === 'toggle'}
    >
      <View style={styles.optionIcon}>
        {option.icon}
      </View>
      
      <View style={styles.optionContent}>
        <Text style={styles.optionTitle}>{option.title}</Text>
        {option.subtitle && (
          <Text style={styles.optionSubtitle}>{option.subtitle}</Text>
        )}
      </View>

      <View style={styles.optionAction}>
        {option.type === 'toggle' ? (
          <Switch
            value={option.value}
            onValueChange={option.onToggle}
            trackColor={{ false: '#E5E5EA', true: '#007AFF' }}
            thumbColor="#FFFFFF"
          />
        ) : (
          <ChevronRight size={20} color="#C7C7CC" />
        )}
      </View>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Profil</Text>
        <TouchableOpacity style={styles.settingsButton}>
          <Settings size={24} color="#007AFF" />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Profile Card */}
        <View style={styles.profileCard}>
          <View style={styles.avatarContainer}>
            <Image
              source={{
                uri: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop'
              }}
              style={styles.avatar}
            />
            <TouchableOpacity style={styles.cameraButton}>
              <Camera size={16} color="#FFFFFF" />
            </TouchableOpacity>
          </View>
          
          <View style={styles.profileInfo}>
            <Text style={styles.profileName}>John Doe</Text>
            <Text style={styles.profileStatus}>Hey there! I am using LIORA.</Text>
            <Text style={styles.profilePhone}>+62 812 3456 7890</Text>
          </View>
          
          <TouchableOpacity style={styles.editButton}>
            <Edit size={20} color="#007AFF" />
          </TouchableOpacity>
        </View>

        {/* Options */}
        <View style={styles.optionsContainer}>
          {profileOptions.map(renderProfileOption)}
        </View>

        {/* Logout Button */}
        <TouchableOpacity style={styles.logoutButton}>
          <LogOut size={24} color="#FF3333" />
          <Text style={styles.logoutText}>Keluar</Text>
        </TouchableOpacity>

        {/* App Info */}
        <View style={styles.appInfo}>
          <Text style={styles.appInfoText}>LIORA Chat</Text>
          <Text style={styles.appInfoText}>Versi 1.0.0</Text>
          <Text style={styles.appInfoText}>© 2024 LIORA Inc.</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 8,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#F2F2F7',
  },
  title: {
    fontSize: 32,
    fontFamily: 'Inter-Bold',
    color: '#1C1C1E',
  },
  settingsButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F2F2F7',
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    flex: 1,
  },
  profileCard: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 20,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#F2F2F7',
  },
  avatarContainer: {
    position: 'relative',
    marginRight: 16,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
  },
  cameraButton: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#007AFF',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  profileInfo: {
    flex: 1,
  },
  profileName: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1C1C1E',
    marginBottom: 4,
  },
  profileStatus: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#8E8E93',
    marginBottom: 4,
  },
  profilePhone: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#007AFF',
  },
  editButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F2F2F7',
    alignItems: 'center',
    justifyContent: 'center',
  },
  optionsContainer: {
    marginTop: 8,
  },
  optionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#F2F2F7',
  },
  optionIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F2F2F7',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  optionContent: {
    flex: 1,
  },
  optionTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1C1C1E',
    marginBottom: 2,
  },
  optionSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#8E8E93',
  },
  optionAction: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 16,
    marginTop: 32,
    paddingVertical: 16,
    borderRadius: 12,
    backgroundColor: '#FFF2F2',
    borderWidth: 1,
    borderColor: '#FFE5E5',
    gap: 12,
  },
  logoutText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#FF3333',
  },
  appInfo: {
    alignItems: 'center',
    paddingVertical: 32,
    paddingHorizontal: 16,
  },
  appInfoText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#C7C7CC',
    marginBottom: 2,
  },
});