import { Redirect } from 'expo-router';

export default function Index() {
  // Untuk sementara redirect ke login
  // Nanti bisa ditambahkan logic untuk check authentication state
  return <Redirect href="/(auth)/login" />;
}